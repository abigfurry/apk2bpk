package com.example.apk2bpk;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final int REQUEST_PICK_FILE = 100;
    private static final int REQ_MANAGE_STORAGE = 101;

    private Button btnApk2Bpk, btnBpk2Apk, btnSelect, btnConvert;
    private TextView tvPath, tvLog;
    private ProgressBar progressBar;
    private Uri inputUri;
    private String inputName;
    private int currentMode; // 0 = APK → BPK, 1 = BPK → APK

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnApk2Bpk = findViewById(R.id.btn_apk2bpk);
        btnBpk2Apk = findViewById(R.id.btn_bpk2apk);
        btnSelect = findViewById(R.id.btn_select);
        btnConvert = findViewById(R.id.btn_convert);
        tvPath = findViewById(R.id.tv_path);
        tvLog = findViewById(R.id.tv_log);
        progressBar = findViewById(R.id.progress);

        // 模式按钮：设置当前模式，启用文件选择按钮
        btnApk2Bpk.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!checkStoragePermission()) {
                        requestStoragePermission();
                        return;
                    }
                    currentMode = 0;
                    btnSelect.setEnabled(true);
                    btnConvert.setEnabled(false);
                    tvPath.setText("已选择模式：APK → BPK");
                }
            });

        btnBpk2Apk.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!checkStoragePermission()) {
                        requestStoragePermission();
                        return;
                    }
                    currentMode = 1;
                    btnSelect.setEnabled(true);
                    btnConvert.setEnabled(false);
                    tvPath.setText("已选择模式：BPK → APK");
                }
            });

        // 选择文件按钮
        btnSelect.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    startActivityForResult(intent, REQUEST_PICK_FILE);
                }
            });

        // 开始转换按钮
        btnConvert.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startConversion();
                }
            });

        // 首次启动请求权限
        if (!checkStoragePermission()) {
            requestStoragePermission();
        }
    }

    private boolean checkStoragePermission() {
        if (Build.VERSION.SDK_INT >= 30) {
            return Environment.isExternalStorageManager();
        } else {
            // 旧版本默认已获得 WRITE_EXTERNAL_STORAGE 权限
            return true;
        }
    }

    private void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= 30) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
            startActivityForResult(intent, REQ_MANAGE_STORAGE);
        } else {
            // 旧版本无需特殊处理
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_MANAGE_STORAGE) {
            if (Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()) {
                Toast.makeText(this, "已获得所有文件访问权限", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "需要授予权限才能保存文件", Toast.LENGTH_LONG).show();
            }
            return;
        }

        if (requestCode == REQUEST_PICK_FILE && resultCode == RESULT_OK && data != null) {
            inputUri = data.getData();
            inputName = getFileName(inputUri);
            tvPath.setText("已选择: " + inputName);
            btnConvert.setEnabled(true);
        } else {
            tvPath.setText("未选择文件");
            inputUri = null;
            inputName = null;
            btnConvert.setEnabled(false);
        }
    }

    private String getFileName(Uri uri) {
        String name = "unknown";
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = cursor.getString(idx);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) cursor.close();
        }
        return name;
    }

    private void appendLog(final String msg) {
        runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    tvLog.append(msg + "\n");
                }
            });
    }

    private void startConversion() {
        if (inputUri == null) {
            Toast.makeText(this, "请先选择文件", Toast.LENGTH_SHORT).show();
            return;
        }

        // 输出目录：/sdcard/apk2bpk
        final File outDir = new File(Environment.getExternalStorageDirectory(), "apk2bpk");
        if (!outDir.exists()) {
            if (!outDir.mkdirs()) {
                Toast.makeText(this, "无法创建输出目录: " + outDir.getPath(), Toast.LENGTH_LONG).show();
                return;
            }
        }

        // 禁用所有按钮，显示进度条
        btnApk2Bpk.setEnabled(false);
        btnBpk2Apk.setEnabled(false);
        btnSelect.setEnabled(false);
        btnConvert.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
        tvLog.setText("");

        new Thread(new Runnable() {
                @Override
                public void run() {
                    File binFile = null;
                    File inFile = null;
                    try {
                        // 复制可执行文件
                        String abi = Build.CPU_ABI;
                        String assetName = abi.contains("64") ? "apk2bpk_arm64" : "apk2bpk_arm";
                        binFile = new File(getFilesDir(), "apk2bpk");
                        copyAsset(assetName, binFile);
                        binFile.setExecutable(true);

                        // 复制输入文件到缓存
                        inFile = new File(getCacheDir(), inputName);
                        copyUriToFile(inputUri, inFile);

                        // 输出文件名
                        String outName;
                        if (currentMode == 0) { // APK → BPK
                            outName = inputName + ".bpk";
                        } else { // BPK → APK
                            if (inputName.toLowerCase().endsWith(".bpk"))
                                outName = inputName.substring(0, inputName.length() - 4) + ".apk";
                            else
                                outName = inputName + ".apk";
                        }
                        File outFile = new File(outDir, outName);

                        // 执行命令行
                        ProcessBuilder pb = new ProcessBuilder(
                            binFile.getAbsolutePath(),
                            "-i", inFile.getAbsolutePath(),
                            "-o", outFile.getAbsolutePath(),
                            (currentMode == 1) ? "-d" : "",
                            "-v"
                        );
                        pb.redirectErrorStream(true);
                        Process p = pb.start();

                        BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
                        String line;
                        while ((line = reader.readLine()) != null) {
                            appendLog(line);
                        }
                        int exit = p.waitFor();
                        reader.close();

                        if (inFile != null) inFile.delete();

                        if (exit == 0) {
                            appendLog("\n✅ 成功! 文件已保存到:\n" + outFile.getAbsolutePath());
                        } else {
                            appendLog("\n❌ 失败，退出码: " + exit);
                        }
                    } catch (Exception e) {
                        appendLog("异常: " + e.getMessage());
                        e.printStackTrace();
                    } finally {
                        runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    progressBar.setVisibility(View.GONE);
                                    btnApk2Bpk.setEnabled(true);
                                    btnBpk2Apk.setEnabled(true);
                                    btnSelect.setEnabled(true);
                                    btnConvert.setEnabled(true);
                                }
                            });
                    }
                }
            }).start();
    }

    private void copyAsset(String name, File dest) throws Exception {
        InputStream in = null;
        OutputStream out = null;
        try {
            in = getAssets().open(name);
            out = new FileOutputStream(dest);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } finally {
            if (in != null) { try { in.close(); } catch (Exception ignored) {} }
            if (out != null) { try { out.close(); } catch (Exception ignored) {} }
        }
    }

    private void copyUriToFile(Uri uri, File dest) throws Exception {
        InputStream in = null;
        OutputStream out = null;
        try {
            in = getContentResolver().openInputStream(uri);
            if (in == null) throw new Exception("无法读取文件");
            out = new FileOutputStream(dest);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } finally {
            if (in != null) { try { in.close(); } catch (Exception ignored) {} }
            if (out != null) { try { out.close(); } catch (Exception ignored) {} }
        }
    }
}
